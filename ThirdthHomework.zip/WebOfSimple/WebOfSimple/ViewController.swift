//
//  ViewController.swift
//  WebOfSimple
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 lishunli. All rights reserved.
//

import UIKit
import WebKit
class ViewController: UIViewController {
    @IBOutlet weak var website: UITextField!
    @IBOutlet weak var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = URL(string: "http://www.guazi.com")!
        webView.load(URLRequest(url: url))
    }
    @IBAction func back(_ sender: Any) {
        webView.goBack()
    }
    @IBAction func forward(_ sender: Any) {
        webView.goForward()
    }
    @IBAction func go(_ sender: Any) {
        if let newUrl = URL(string: website.text!),newUrl != nil{
            webView.load(URLRequest(url: newUrl))
        }
    }
    @IBAction func refresh(_ sender: Any) {
        webView.reload()
    }
    

}

