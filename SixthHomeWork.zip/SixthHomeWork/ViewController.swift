//
//  ViewController.swift
//  SixthHomeWork
//
//  Created by student on 2018/12/8.
//  Copyright © 2018年 lishunli. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let redView = UIView()
        redView.backgroundColor = UIColor.red
        let grayView = UIView()
        grayView.backgroundColor = UIColor.gray
        let greedView = UIView()
        greedView.backgroundColor = #colorLiteral(red: 0, green: 0.9768045545, blue: 0, alpha: 1)
        let stackView = UIStackView(arrangedSubviews: [redView,grayView,greedView])
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.spacing = 20
        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.leadingAnchor.constraint(equalTo:view.leadingAnchor,constant: 50).isActive = true
         stackView.topAnchor.constraint(equalTo:view.topAnchor,constant: 40).isActive = true
         stackView.trailingAnchor.constraint(equalTo:view.trailingAnchor,constant:-20).isActive = true
         stackView.bottomAnchor.constraint(equalTo:view.bottomAnchor,constant:-100).isActive = true
        
    }


}

